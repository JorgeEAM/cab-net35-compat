<##################
    Functions Block
###################>
Function Add-Path($Path) {
    $Path = [Environment]::GetEnvironmentVariable("PATH", "Machine") + [IO.Path]::PathSeparator + $Path
    [Environment]::SetEnvironmentVariable( "Path", $Path, "Machine" )
}


<########################
    Updated PATH variable
#########################>
$env:path = "${env:path};C:\Windows\System32\inetsrv";


<##########################
    Removed default website
###########################>
Remove-Website -Name 'Default Web Site';
Remove-Item -Recurse -Force C:\inetpub\wwwroot\*;


<############################
    Setting IIS Configuration
#############################>
$info=Get-Content "C:\source\applicationInfo.json" | ConvertFrom-Json

# AppPool Creation
appcmd add apppool /name:$($info.IISitePool.name) /managedRuntimeVersion:$($info.IISitePool.managedRuntimeVersion) /managedPipelineMode:$($info.IISitePool.managedPipelineMode)
# Setting features
$info.IISitePool.features | ForEach-Object {
    appcmd set apppool "$($info.IISitePool.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}

# Site Creation
appcmd add site /name:$($info.IISiteServer.name) /physicalPath:$($info.IISiteServer.physicalpath) /bindings:$($info.IISiteServer.binding)
appcmd list site
# Setting features
$info.IISiteServer.features | ForEach-Object {
    appcmd set site "$($info.IISiteServer.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}

# VirtualApp Creation
appcmd add app /site.name:$($info.IISiteServer.name) /path:/$($info.IISiteApp.name) /physicalPath:$($info.IISiteApp.physicalpath)
# Setting relation between VirtualApp and AppPool
appcmd set app "$($info.IISiteServer.name)/$($info.IISiteApp.name)" /applicationPool:"$($info.IISitePool.name)"
# Setting features
$info.IISiteApp.features | ForEach-Object {
    appcmd set app "$($info.IISiteServer.name)/$($info.IISiteApp.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}


<############################
    Deploying WebApplication
#############################>
Write-Host "Deploying application..."
Expand-Archive -Path "C:\source\DemoApplication.zip" -DestinationPath "C:\source"
Get-ChildItem -Path "C:\source\DemoApplication\*" | Move-Item -Destination "$($info.IISiteApp.physicalpath)" -WhatIf;
Get-ChildItem -Path "C:\source\DemoApplication\*" | Move-Item -Destination "$($info.IISiteApp.physicalpath)";
Write-Host "Application deployed."
